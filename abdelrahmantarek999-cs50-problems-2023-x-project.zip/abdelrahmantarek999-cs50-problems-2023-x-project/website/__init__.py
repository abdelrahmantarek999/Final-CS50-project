from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from os import path
from flask_login import LoginManager

# define a database
db = SQLAlchemy()
DB_NAME = "database.db"


def create_app():
    app = Flask(__name__) #initialize app
    app.config['SECRET_KEY'] = 'abdelrahman tarek' #this is the secret key for the app
    app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{DB_NAME}' #db location
    db.init_app(app) #initialize db

    #import the blueprints
    from .views import views
    from .auth import auth

    # register the blueprints with flask application
    # now i can access any route inside views or auth by placing the name of the route after the '/'
    app.register_blueprint(views, url_prefix='/')
    app.register_blueprint(auth, url_prefix='/')

    # check if db is created if not create it
    from .models import User, Note

    with app.app_context():
        db.create_all()

    login_manager = LoginManager()
    login_manager.login_view = 'auth.firstpage'
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(id):
        return User.query.get(int(id))

    #return function
    return app

# function that creates the database
def create_database(app):
    if not path.exists('website/' + DB_NAME):
        db.create_all(app=app)
        print('Created Database!')
