# NOTECIA
#### Video Demo:  <https://youtu.be/qW9kmMdmqMc>
#### Description: This website is a note-taking application that is written using Flask, HTML, Bootstrap CSS and JS, and SQLAlchemy. Users can login and logout, create accounts, add or delete notes on the database, and access them anywhere and anytime quickly and easily.
</br>
</br>

To run the app:
```bash
    Click on main.py after opening project file and press run on the top right corner.
```
</br>

### 1   |   Site navigation
#### hompage / firstpage

![homepage](README_images/homepage.PNG)

This is the main page. The link "NOTECIA" takes you to /firstpage. Users can sign up for an account and/or log in on the right side of the navigation bar. Users who do not plan to log in to a registered account are not permitted to use the site.

### 2   |   Features
#### User Login, registration & sessions

![signup](README_images/signup.PNG)

users can sign up for a new account.

![login](README_images/login.PNG)

This website employs sessions to keep track of the current user who is logged in. Furthermore, it is utilised to transfer data from one page to another.

### 3   |   HOME
#### homepage

![home](README_images/home.PNG)

The website is designed to be user-friendly and easy to use. Users can easily create an account and start adding notes. The notes are stored in the database, so they can be accessed from anywhere and anytime.

### 4 | How to Use the Website

To use the website, simply visit the website and create an account. Once you have created an account, you can start adding notes. To add a note, simply click on the "Add Note" button and enter the title and content of the note. You can also add tags to the note to help you find it later.

To view your notes, simply click on the "Notes" tab. You can also search for notes by title, content, or tags.

To delete a note, simply click on the "Delete" button next to the note.

### 5   |   Database
####  (SQLAlchemy)

![db](README_images/db.PNG)

SQLAlchemy is used to manage the database, which stores the users' notes.

### 6 | Tech used and Benefits

#### Tech

- Flask Web Framework: A Python microframework that is used to build web applications. It is lightweight and easy to use, making it a good choice for small projects like this one.
- HTML: The markup language that is used to create the structure of web pages. It is used to define the elements of a page, such as headers, paragraphs, and images.
- Boostrap CSS: Bootstrap is a CSS framework that is used to style web pages. It provides a number of pre-built components and styles that can be used to quickly and easily create attractive and responsive web pages.
- Boostrap JS Framework
- SQLAlchemy: Python library that is used to interact with databases. It provides a high-level abstraction that makes it easy to perform database operations, such as creating, querying, and updating tables.

These technologies are all open source and free to use. They are also well-documented and supported by a large community of developers. This makes them a good choice for building a reliable and scalable web application.

In addition to these technologies, the website also uses a number of other libraries and tools, such as Werkzeug, Jinja2, and WTForms. These libraries provide additional functionality that is not included in the core Flask framework.

The website is hosted on a cloud-based platform, such as Amazon Web Services or Google Cloud Platform. This allows the website to be scaled up or down as needed, and it also provides a secure environment for storing the users' data.

#### Benefits

There are many benefits to using this website to store notes. Some of the benefits include:

- The website is designed to be responsive, so it can be used on a variety of devices, including smartphones, tablets, and laptops.
- The website is secure, using HTTPS to encrypt all traffic between the user's browser and the server.
- The website is easy to use.
- The notes are stored in the database, so they can be accessed from anywhere and anytime.
- easily delete notes.


### 7 | Summary

The website is built on the Flask microframework, which is a lightweight and easy-to-use Python framework for web development. HTML is used to create the static pages of the website, while Bootstrap CSS and JS are used to style the pages and provide additional functionality. SQLAlchemy is used to manage the database, which stores the users' notes.

The website is designed to be user-friendly and easy to use. Users can easily create an account and start adding notes. The notes are stored in the database, so they can be accessed from anywhere and anytime so users can easily find the notes they are looking for.

### 8 | References
- W3School
- Stack Overflow
- Bootstrap
- Flask school - python web development