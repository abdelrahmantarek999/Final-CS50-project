#the reason this is done is because webapp is a python package via __init__.py that why i can import it
from website import create_app

app = create_app()

# this allows me to have a running flask web server
if __name__ == '__main__':
    app.run(debug=True) #anytime i make a change its going to automaitcally run it for me
